import React, { useEffect, useState } from "react";
import "./User-tool/User.css";
import "./User-tool/userResponsive.css";
import Navbar from "./Navbar";
import { useDispatch, useSelector } from "react-redux";
import { GET_PARTYCONNECT_PROGRESS } from "../../Redux-saga/Admin_Code/Admin/PartyConnect/action/action";
import { VOTE_POST_PROGRESS } from "../../Redux-saga/User_code/voting/action";
import Cookies from "js-cookie";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import axios from "axios";
import { BASE_URL, GET_VOTE } from "../../Redux-saga/constant";
import { ethers } from "ethers";
import HelloWorldABI from "../../HelloWorldABI.json";

const Voting = () => {
  const { ethereum } = window;

  const [vote, setVote] = useState();
  const [ChakeVote, setChakeVote] = useState(false);
  const [smart, setsmart] = useState("");

  const userId = Cookies.get("_id");
  const CARDNUMBER = Cookies.get("cardNo");

  const GetVoteList = async () => {
    const userData = [];
    const res = await axios.get(BASE_URL + GET_VOTE);
    const userinfo = res.data.data;
    userinfo.map((i) => userData.push(i.user.cardNo));
    if (userData.includes(CARDNUMBER)) {
      setChakeVote(true);
    } else {
      setChakeVote(false);
    }
    console.log(userData);
  };

  const MySwal = withReactContent(Swal);

  const dispatch = useDispatch();

  const { PartyConnectData } = useSelector(
    (state) => state.PartyConnectReducer
  );

  console.log(PartyConnectData, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");


  useEffect(() => {
    dispatch({ type: GET_PARTYCONNECT_PROGRESS });
    setsmart("0x817643909aAda80c548AC6420C7C60Af165bD577");
    GetVoteList();
  }, []);

  const fetchData = (index) => {
    let data = {
      user: userId,
      party: PartyConnectData[index].party._id,
      election: PartyConnectData[index].election._id,
    };
    setVote({ ...vote, ...data });
  };

  const submitVote = async () => {
    //blockchain

    // const input = mess.current.value;
    const addr = "0x817643909aAda80c548AC6420C7C60Af165bD577";
    const provider = new ethers.BrowserProvider(ethereum);

    const block = await provider.getBlock();
    const tx = await block.transactions;
    console.log(tx);

    // const result = await provider.getNetwork();
    // console.log(result);
    // console.log(provider.getAvatar());
    const signer = await provider.getSigner();
    // const signer = new ethers.Wallet(
    //   "c6d107e2e51d6f0f97b89fd99a9580c6feb453db1d4a07194b54d566666fa9be",
    //   provider
    // );
    console.log(signer);

    // contract instance
    const helloWorldContract = new ethers.Contract(
      addr,
      HelloWorldABI.abi,
      signer
    );

    const update = await helloWorldContract.getFunction("update");
    const message = await helloWorldContract.getFunction("message");
    const ress = await helloWorldContract;
    const res = await message();

    const mess = vote.party;
    // console.log(mess);
    update(vote.party);

    console.log(res);

    if (vote == null) {
      MySwal.fire({
        title: "Please Select a Particular Party !",
        icon: "warning",
        showCancelButton: false,
        confirmButtonText: "Sure",
      }).then((result) => {
        if (result.isConfirmed) {
          window.location = "/";
        }
      });
    } else {
      MySwal.fire({
        title: "Your Vote Is Successfully Submitted !",
        // text: "You have submitted a vote ?",
        text: `${smart}`,
        icon: "success",
        showCancelButton: true,
        confirmButtonText: "Thank You For Voting",
        cancelButtonText: "No, cancel",
      }).then(async (result) => {
        if (result.isConfirmed) {
          console.log(vote);
          dispatch({ type: VOTE_POST_PROGRESS, payload: vote });
          setTimeout(() => {
            handleConformClick();
          }, 600);
        }
      });
    }
  };

  const handleConformClick = () => {
    Cookies.remove("role");
    Cookies.remove("name");
    Cookies.remove("_id");
    Cookies.remove("cardNo");
    window.location = "/";
  };

  return (
    <>
      <Navbar />
      {ChakeVote ? (
        <>
          {MySwal.fire({
            title: "You have already submitted a vote",
            text: "Thank you for visiting!",
            icon: "info",
            confirmButtonText: "Confirm",
          }).then((result) => {
            if (result.isConfirmed) {
              handleConformClick();
            }
          })}
        </>
      ) : (
        <>
          <div className="vt">
            <table class="table table-bordered text-center w-50 mb-0">
              <thead>
                <tr className="border-black">
                  <th>No.</th>
                  <th>Indian Political Party</th>
                  <th>Symbols</th>
                  <th>Button </th>
                </tr>
              </thead>
              <tbody className="table-bordered">
                {PartyConnectData.map((v, i) => (
                  <tr key={i}>
                    <td className="pd">{i + 1}</td>
                    <td className="pd">{v.party?.party_name}</td>
                    <td className="w-25">
                      <div className="party-logo">
                        <img
                          src={v.party?.party_logo}
                          alt={v.party?.party_logo}
                          className="w-50"
                        />
                      </div>
                    </td>
                    <td className="pd">
                      <input
                        type="radio"
                        name="party"
                        onChange={() => fetchData(i)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button onClick={submitVote}>Submit</button>
          </div>
        </>
      )}
    </>
  );
};

export default Voting;
